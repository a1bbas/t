from odoo import models, fields, api

class ContractReviewWizard(models.TransientModel):
    _name = 'contract.review.wizard'
    _description = 'Select Sale Order to Print Contract Review Sheet'

    sale_order_id = fields.Many2one('sale.order', string="Sale Order", required=True)

    def action_print_contract_review(self):
        return self.env.ref('contract_review_sheet.action_report_contract_sheet').report_action(self.sale_order_id)
