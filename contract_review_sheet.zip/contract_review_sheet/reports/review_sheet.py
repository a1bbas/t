from odoo import models, fields, api

class ContractReviewSheet(models.Model):
    _inherit = 'sale.order'

    

    def get_report_name(self):
        return "Contract Revew Sheet"

