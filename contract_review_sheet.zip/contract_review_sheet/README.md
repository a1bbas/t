# Contract Review Sheet

**Module Name:** `Contract Review Sheet`  
**Version:** 13.0  
**Category:** Sale  
**Author:** Evolve Services  
**Developer:** Nasir (Rhein) & Faizan Mughal  
**Website:** [Evolve Services](https://evolve.pk)  
**License:** LGPL-3  

---

## Summary
The **Contract Review Sheet** module for Odoo 13 enhances the sale order workflow by adding a custom print option. It enables users to print a Contract Review Sheet directly from the sale orders, making contract management and documentation easier.

## Features
- Adds a **Contract Review Sheet** print option to sale orders.
- Provides a formatted report template for contract review purposes.
- Easy installation and integration with the default Odoo sale module.

## Dependencies
- **Sale Module** (`sale`): This module depends on Odoo's default Sale module to function.

## Installation
1. Download or clone this repository into your Odoo custom addons directory.
2. Update the Odoo app list.
3. Install the "Contract Review Sheet" module from the Apps menu.

## Usage
1. Navigate to **Sales > Sales Orders**.
2. Open a sale order and select the "Contract Review Sheet" print option to generate the report.
3. Print or save the generated Contract Review Sheet as needed.

## Configuration
No additional configuration is required for this module.

## Data Files
- **contract_review_sheet.xml**: Defines the template layout for the Contract Review Sheet report.

## License
This module is licensed under the LGPL-3 license, allowing modification and redistribution in line with the license terms.

---
![alt text](image.png)

![img.png](img.png)