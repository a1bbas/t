{
    'name': 'Contract Review Sheet',
    'version': '13.0',
    'category': 'sale',
    'author': 'Evolve Services',
    'Website': 'https://evolve.pk',
    'Developer': 'Nasir (Rhein) & Faizan Mughal',
    'summary': 'Add Contract Review Sheet print option to Sale Orders',
    'description': """This module adds a custom report option for printing the Contract Review Sheet in Sale Orders.""",
    'depends': ['purchase', 'sale'],
    'data': [
        'views/contract_review_wizard_view.xml',
        'views/purchase_menu_action.xml',
        'reports/contract_review_sheet.xml',
    ],
    'installable': True,
    'application': False,
}
