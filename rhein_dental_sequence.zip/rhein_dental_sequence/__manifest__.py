{
    'name': 'Custom Document Sequences',
    'version': '13.0.1.0.0',
    'summary': 'Custom Sequences for SO, PO, and Invoices',
    'category': 'Customization',
    'depends': ['sale', 'purchase', 'account','mrp'],
    'data': [
        'views/sequence_data.xml',
    ],
    'installable': True,
    'auto_install': False,
}
